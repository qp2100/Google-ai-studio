import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import ChatList from './components/ChatList';
import ChatWindow from './components/ChatWindow';
import Moments from './components/Moments';
import ContactList from './components/ContactList';
import Profile from './components/Profile';
import Auth from './components/Auth';
import AdminDashboard from './components/AdminDashboard';
import { Tab, ChatSession, User } from './types';
import { MockBackend } from './services/mockBackend';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('chat');
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [isAdminMode, setIsAdminMode] = useState(false);

  // Init Data on Load
  useEffect(() => {
    MockBackend.init();
    const currentUser = MockBackend.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setChats(MockBackend.getChats());
    }
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setChats(MockBackend.getChats());
  };

  const handleLogout = () => {
    MockBackend.logout();
    setUser(null);
    setSelectedChatId(null);
    setActiveTab('chat');
  };

  // Helper to keep user state in sync (e.g. balance updates)
  const handleUserUpdate = (updatedUser: User) => {
      setUser(updatedUser);
      // Also update local storage backing
      MockBackend.updateUser(updatedUser.id, updatedUser);
  };

  // Helper to start or focus a chat from Contacts or after creating a group
  // targetId can be a Contact ID (for DM) or a Chat ID (for Group)
  const handleStartChat = (targetId: string) => {
    // Refresh chats in case a group was just made
    const currentChats = MockBackend.getChats();
    setChats(currentChats);
    
    // 1. Check if targetId is an existing CHAT ID (Group or DM)
    const existingChatById = currentChats.find(c => c.id === targetId);
    if (existingChatById) {
        setSelectedChatId(existingChatById.id);
        setActiveTab('chat');
        return;
    }
    
    // 2. Check if DM exists for this CONTACT ID (Legacy DM lookup)
    const existingDm = currentChats.find(c => !c.isGroup && c.participantId === targetId);
    
    if (existingDm) {
      setSelectedChatId(existingDm.id);
      setActiveTab('chat');
    } else {
      // 3. Create new DM
      const newChat: ChatSession = {
        id: `chat-${Date.now()}`,
        participantId: targetId,
        lastMessage: '',
        lastMessageTime: Date.now(),
        unreadCount: 0,
        messages: []
      };
      const updatedChats = [newChat, ...currentChats];
      setChats(updatedChats);
      MockBackend.saveChats(updatedChats);
      setSelectedChatId(newChat.id);
      setActiveTab('chat');
    }
  };

  if (isAdminMode) {
      return <AdminDashboard onExit={() => setIsAdminMode(false)} />;
  }

  if (!user) {
    return <Auth onLogin={handleLogin} onAdminEnter={() => setIsAdminMode(true)} />;
  }

  // Logic for responsive view rendering
  // Desktop: Sidebar -> List -> Content
  // Mobile: Tab Bar -> Content (List or Detail)

  const renderContent = () => {
    return (
      <Layout activeTab={activeTab} onTabChange={(tab) => {
        setActiveTab(tab);
        // On mobile, if switching tabs, we might want to clear selected chat if we want to show list first
        if (window.innerWidth < 768) {
            setSelectedChatId(null); 
        }
      }}>
        {/* Responsive Logic */}
        
        {/* DESKTOP VIEW */}
        <div className="hidden md:flex w-full h-full">
            {/* Middle Column (List) */}
            <div className="w-[320px] h-full bg-[#e6e6e6] border-r border-gray-200">
                {activeTab === 'chat' && (
                    <ChatList 
                        chats={chats} 
                        activeChatId={selectedChatId} 
                        onSelectChat={setSelectedChatId} 
                    />
                )}
                {activeTab === 'contacts' && (
                    <ContactList onSelectContact={handleStartChat} currentUser={user} />
                )}
                {activeTab === 'discover' && (
                    <div className="p-4 text-gray-500">点击列表中的“朋友圈”查看动态</div>
                )}
                {activeTab === 'me' && (
                    <div className="p-4 text-gray-500">设置列表</div>
                )}
            </div>
            
            {/* Right Column (Detail) */}
            <div className="flex-1 h-full bg-[#f5f5f5]">
                {activeTab === 'chat' && selectedChatId ? (
                    <ChatWindow 
                        chatId={selectedChatId} 
                        chats={chats} 
                        setChats={setChats}
                        currentUser={user}
                        onUpdateUser={handleUserUpdate}
                    />
                ) : activeTab === 'chat' ? (
                     <div className="flex items-center justify-center h-full text-gray-400">
                         <div className="text-center">
                            <div className="w-16 h-16 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                                <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                            </div>
                            <p>选择一个聊天开始发送消息</p>
                         </div>
                     </div>
                ) : null}

                {activeTab === 'discover' && <Moments />}
                {activeTab === 'contacts' && <div className="flex items-center justify-center h-full text-gray-400">选择联系人查看详情</div>}
                {activeTab === 'me' && (
                    <Profile 
                        currentUser={user} 
                        onUpdateUser={handleUserUpdate} 
                        onLogout={handleLogout}
                    />
                )}
            </div>
        </div>


        {/* MOBILE VIEW */}
        <div className="md:hidden w-full h-full relative">
            {/* If we are in 'chat' tab and a chat is selected, show ChatWindow fullscreen */}
            {activeTab === 'chat' && selectedChatId ? (
                <div className="absolute inset-0 z-20 bg-white">
                    <ChatWindow 
                        chatId={selectedChatId} 
                        chats={chats} 
                        setChats={setChats} 
                        currentUser={user}
                        onUpdateUser={handleUserUpdate}
                        onBack={() => setSelectedChatId(null)}
                    />
                </div>
            ) : null}

            {/* Otherwise show the main tab content */}
            <div className={`${selectedChatId && activeTab === 'chat' ? 'hidden' : 'block'} h-full`}>
                {activeTab === 'chat' && (
                    <ChatList 
                        chats={chats} 
                        activeChatId={selectedChatId} 
                        onSelectChat={setSelectedChatId} 
                        className="w-full"
                    />
                )}
                {activeTab === 'contacts' && <ContactList onSelectContact={handleStartChat} currentUser={user} />}
                {activeTab === 'discover' && <Moments />}
                {activeTab === 'me' && (
                    <Profile 
                        currentUser={user} 
                        onUpdateUser={handleUserUpdate} 
                        onLogout={handleLogout}
                    />
                )}
            </div>
        </div>

      </Layout>
    );
  };

  return renderContent();
}

export default App;