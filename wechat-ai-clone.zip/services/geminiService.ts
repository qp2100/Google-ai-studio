import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

let ai: GoogleGenAI | null = null;
let chatSession: Chat | null = null;

const getAIClient = () => {
  if (!ai) {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return ai;
};

export const getGeminiChatResponseStream = async (
  message: string, 
  history: { role: 'user' | 'model'; parts: { text: string }[] }[]
): Promise<AsyncIterable<GenerateContentResponse>> => {
  const client = getAIClient();
  
  // Re-create chat session if needed or if history changes significantly (simplified for this demo)
  // In a real app, we might maintain one chat instance per conversation ID.
  if (!chatSession) {
    chatSession = client.chats.create({
      model: 'gemini-3-flash-preview',
      history: history,
      config: {
        systemInstruction: "You are a helpful, witty, and concise AI assistant inside a messaging app similar to WeChat. Keep responses relatively short and conversational.",
      }
    });
  }

  // Send message
  return chatSession.sendMessageStream({ message });
};
