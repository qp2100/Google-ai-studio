import { User, ChatSession, Message, Moment, MomentComment } from '../types';
import { INITIAL_CHATS, CONTACTS, CURRENT_USER, INITIAL_MOMENTS } from '../constants';

// Keys for LocalStorage
const STORAGE_KEYS = {
  USER: 'wechat_user',
  USERS: 'wechat_users',
  CHATS: 'wechat_chats',
  MOMENTS: 'wechat_moments'
};

// Initialize Mock Data if empty
const initializeData = () => {
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    const devUser: User = {
        id: '2232', // Updated ID
        name: '系统管理员',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Admin',
        isDeveloper: true,
        walletBalance: 99999999,
        password: '123', // Updated Password
        wxid: 'admin_core',
        isBanned: false
    };

    // Ensure we have current user, contacts, and the dev admin
    const initialUsers = [CURRENT_USER, ...CONTACTS, devUser].map(u => {
        // Preserve specific props if already defined in constant, else default
        return {
            walletBalance: 1000, 
            password: '123', 
            isBanned: false,
            ...u
        };
    });
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(initialUsers));
  }
  if (!localStorage.getItem(STORAGE_KEYS.CHATS)) {
    localStorage.setItem(STORAGE_KEYS.CHATS, JSON.stringify(INITIAL_CHATS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.MOMENTS)) {
    localStorage.setItem(STORAGE_KEYS.MOMENTS, JSON.stringify(INITIAL_MOMENTS));
  }
};

export const MockBackend = {
  init: initializeData,

  // --- Auth & User ---
  login: async (username: string, password: string): Promise<User | null> => {
    await new Promise(r => setTimeout(r, 500));
    const users: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    // Allow login by name OR id (for the 2232 account)
    const user = users.find(u => (u.name === username || u.id === username) && u.password === password);
    if (user) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
      return user;
    }
    return null;
  },

  register: async (username: string, password: string): Promise<User> => {
    await new Promise(r => setTimeout(r, 500));
    const users: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: username,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      password,
      walletBalance: 1000,
      wxid: `wxid_${Math.floor(Math.random() * 1000000)}`,
      isBanned: false
    };
    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(newUser));
    return newUser;
  },

  // Admin: Create User directly
  createUser: (user: Partial<User>): User => {
      const users: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
      const newUser: User = {
          id: `user-${Date.now()}`,
          name: user.name || 'New User',
          password: user.password || '123',
          avatar: user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${Date.now()}`,
          walletBalance: user.walletBalance || 0,
          wxid: user.wxid || `wxid_${Math.floor(Math.random() * 1000000)}`,
          isBanned: false,
          ...user
      } as User;
      
      users.push(newUser);
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      return newUser;
  },

  getCurrentUser: (): User | null => {
    const u = localStorage.getItem(STORAGE_KEYS.USER);
    return u ? JSON.parse(u) : null;
  },

  // Admin: Get ALL users
  getAllUsers: (): User[] => {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
  },

  updateUser: (userId: string, updates: Partial<User>): User | null => {
      const users: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
      const index = users.findIndex(u => u.id === userId);
      if (index !== -1) {
          users[index] = { ...users[index], ...updates };
          localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
          
          // If updating current logged in user, update session too
          const currentUser = MockBackend.getCurrentUser();
          if (currentUser && currentUser.id === userId) {
             const updatedUser = { ...currentUser, ...updates };
             localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));
             return updatedUser;
          }
          return users[index];
      }
      return null;
  },

  deleteUser: (userId: string) => {
      let users: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
      users = users.filter(u => u.id !== userId);
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));

      // Also logout if deleting self
      const currentUser = MockBackend.getCurrentUser();
      if (currentUser && currentUser.id === userId) {
          MockBackend.logout();
      }
  },

  logout: () => {
    localStorage.removeItem(STORAGE_KEYS.USER);
  },

  // --- Contacts ---
  getContacts: (): User[] => {
    const allUsers: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const currentUser = MockBackend.getCurrentUser();
    if (!currentUser) return [];
    return allUsers.filter(u => u.id !== currentUser.id);
  },

  addFriend: async (name: string): Promise<boolean> => {
    await new Promise(r => setTimeout(r, 500));
    const allUsers: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    return allUsers.some(u => u.name === name);
  },

  // --- Chats ---
  getChats: (): ChatSession[] => {
    const chats: ChatSession[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.CHATS) || '[]');
    return chats;
  },

  saveChats: (chats: ChatSession[]) => {
    localStorage.setItem(STORAGE_KEYS.CHATS, JSON.stringify(chats));
  },

  createGroupChat: async (name: string, participantIds: string[]): Promise<ChatSession> => {
    await new Promise(r => setTimeout(r, 300));
    const chats = MockBackend.getChats();
    const newChat: ChatSession = {
      id: `group-${Date.now()}`,
      isGroup: true,
      groupName: name,
      participantIds: participantIds,
      lastMessage: '群聊已创建',
      lastMessageTime: Date.now(),
      unreadCount: 0,
      messages: []
    };
    chats.unshift(newChat);
    MockBackend.saveChats(chats);
    return newChat;
  },

  addGroupMember: (chatId: string, userId: string) => {
    const chats = MockBackend.getChats();
    const chat = chats.find(c => c.id === chatId);
    if (chat && chat.isGroup && chat.participantIds) {
      if (!chat.participantIds.includes(userId)) {
        chat.participantIds.push(userId);
        
        // System message
        const sysMsg: Message = {
            id: Date.now().toString(),
            senderId: 'system',
            text: '邀请了新成员加入群聊',
            type: 'text',
            timestamp: Date.now()
        };
        chat.messages.push(sysMsg);
        
        MockBackend.saveChats(chats);
      }
    }
    return chats;
  },

  deleteChat: (chatId: string) => {
      let chats = MockBackend.getChats();
      chats = chats.filter(c => c.id !== chatId);
      MockBackend.saveChats(chats);
  },

  // --- Wallet ---
  updateBalance: (userId: string, amount: number) => {
    const users: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const idx = users.findIndex(u => u.id === userId);
    if (idx !== -1) {
      users[idx].walletBalance = (users[idx].walletBalance || 0) + amount;
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      
      const currentUser = MockBackend.getCurrentUser();
      if (currentUser && currentUser.id === userId) {
        currentUser.walletBalance = users[idx].walletBalance;
        localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
      }
    }
  },

  // --- Moments ---
  getMoments: (): Moment[] => {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.MOMENTS) || '[]');
  },

  addMoment: (userId: string, content: string, images: string[]): Moment => {
      const moments = MockBackend.getMoments();
      const newMoment: Moment = {
          id: `moment-${Date.now()}`,
          userId,
          content,
          images,
          likedBy: [],
          comments: [],
          timestamp: Date.now()
      };
      // Add to beginning
      moments.unshift(newMoment);
      localStorage.setItem(STORAGE_KEYS.MOMENTS, JSON.stringify(moments));
      return newMoment;
  },

  toggleLike: (momentId: string, userId: string) => {
      const moments = MockBackend.getMoments();
      const moment = moments.find(m => m.id === momentId);
      if (moment) {
          if (moment.likedBy.includes(userId)) {
              moment.likedBy = moment.likedBy.filter(id => id !== userId);
          } else {
              moment.likedBy.push(userId);
          }
          localStorage.setItem(STORAGE_KEYS.MOMENTS, JSON.stringify(moments));
      }
      return moments;
  },

  addComment: (momentId: string, userId: string, userName: string, content: string) => {
      const moments = MockBackend.getMoments();
      const moment = moments.find(m => m.id === momentId);
      if (moment) {
          const newComment: MomentComment = {
              id: `c-${Date.now()}`,
              userId,
              userName,
              content
          };
          moment.comments.push(newComment);
          localStorage.setItem(STORAGE_KEYS.MOMENTS, JSON.stringify(moments));
      }
      return moments;
  }
};