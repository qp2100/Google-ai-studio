import { User, ChatSession, Moment } from './types';

export const CURRENT_USER: User = {
  id: 'me',
  name: '旅行者',
  avatar: 'https://picsum.photos/id/64/200/200',
  wxid: 'wxid_888888'
};

export const AI_BOT_ID = 'gemini-bot';

export const CONTACTS: User[] = [
  {
    id: AI_BOT_ID,
    name: 'Gemini AI 助手',
    avatar: 'https://upload.wikimedia.org/wikipedia/commons/8/8a/Google_Gemini_logo.svg',
    isBot: true,
  },
  {
    id: 'user-2',
    name: '马斯克',
    avatar: 'https://picsum.photos/id/1025/200/200',
  },
  {
    id: 'user-3',
    name: '爱丽丝',
    avatar: 'https://picsum.photos/id/832/200/200',
  },
  {
    id: 'user-4',
    name: '鲍勃',
    avatar: 'https://picsum.photos/id/1005/200/200',
  },
];

export const INITIAL_CHATS: ChatSession[] = [
  {
    id: 'chat-1',
    participantId: AI_BOT_ID,
    lastMessage: '你好！我是你的 Gemini AI 助手。',
    lastMessageTime: Date.now(),
    unreadCount: 1,
    messages: [
      {
        id: 'msg-0',
        senderId: AI_BOT_ID,
        text: '你好！我是你的 Gemini AI 助手。有什么可以帮你的吗？',
        timestamp: Date.now(),
        type: 'text',
      },
    ],
  },
  {
    id: 'chat-2',
    participantId: 'user-2',
    lastMessage: '我们要去火星吗？',
    lastMessageTime: Date.now() - 3600000,
    unreadCount: 0,
    messages: [
      {
        id: 'msg-1',
        senderId: 'user-2',
        text: '嘿，看火箭发射了吗？',
        timestamp: Date.now() - 3605000,
        type: 'text',
      },
      {
        id: 'msg-2',
        senderId: 'me',
        text: '看了！太壮观了。',
        timestamp: Date.now() - 3602000,
        type: 'text',
      },
      {
        id: 'msg-3',
        senderId: 'user-2',
        text: '我们要去火星吗？',
        timestamp: Date.now() - 3600000,
        type: 'text',
      },
    ],
  },
];

export const INITIAL_MOMENTS: Moment[] = [
  {
    id: 'moment-1',
    userId: 'user-3',
    content: '今天的日落真美！ 🌅',
    images: ['https://picsum.photos/id/10/400/300', 'https://picsum.photos/id/11/400/300'],
    likedBy: ['user-2', 'me'],
    comments: [
        { id: 'c1', userId: 'user-2', userName: '马斯克', content: '很棒的风景！' }
    ],
    timestamp: Date.now() - 7200000,
  },
  {
    id: 'moment-2',
    userId: 'user-2',
    content: '刚刚又发射了一枚火箭。基操勿6。 🚀',
    images: ['https://picsum.photos/id/20/400/300'],
    likedBy: ['user-3', 'user-4', 'me'],
    comments: [],
    timestamp: Date.now() - 86400000,
  },
  {
    id: 'moment-3',
    userId: AI_BOT_ID,
    content: '今天处理了一百万个 Token，感觉很充实。',
    images: [],
    likedBy: [],
    comments: [],
    timestamp: Date.now() - 120000000,
  },
];
