import React, { useState } from 'react';
import { User } from '../types';
import { ChevronLeft, CreditCard, DollarSign, GripHorizontal } from 'lucide-react';
import { MockBackend } from '../services/mockBackend';

interface WalletProps {
  onBack: () => void;
  currentUser: User;
  onUpdateUser: (user: User) => void;
}

const Wallet: React.FC<WalletProps> = ({ onBack, currentUser, onUpdateUser }) => {
  const [balance, setBalance] = useState(currentUser.walletBalance || 0);

  const handleTopUp = () => {
    // 1. Prompt for password first
    const password = prompt("请输入充值密码 (提示: 223201):");
    
    // 2. Validate password
    if (password === "223201") {
        // 3. Prompt for amount if password is correct
        const amountStr = prompt("密码正确！请输入充值金额:");
        if (!amountStr) return; // User cancelled
        
        const amount = parseFloat(amountStr);
        if (isNaN(amount) || amount <= 0) {
            alert("请输入有效的金额");
            return;
        }

        // 4. Perform Top-up
        MockBackend.updateBalance(currentUser.id, amount);
        const newBalance = (currentUser.walletBalance || 0) + amount;
        setBalance(newBalance);
        
        // Update parent state
        onUpdateUser({ ...currentUser, walletBalance: newBalance });
        
        alert(`成功充值 ¥${amount.toFixed(2)}`);
    } else {
        // Password incorrect or cancelled
        alert("密码错误或未输入，无法使用充值功能！");
    }
  };

  return (
    <div className="h-full bg-[#f5f5f5] flex flex-col w-full absolute top-0 left-0 z-50">
      <div className="bg-[#ededed] px-4 py-3 flex items-center justify-between">
          <button onClick={onBack} className="flex items-center text-black">
              <ChevronLeft /> 返回
          </button>
          <span className="font-semibold">支付</span>
          <div className="w-6"></div>
      </div>

      <div className="bg-[#07C160] m-4 rounded-xl p-6 text-white shadow-lg relative overflow-hidden">
          <div className="flex items-center space-x-2 mb-8">
              <CreditCard />
              <span>收付款</span>
          </div>
          <div className="flex items-end space-x-1">
              <span className="text-lg font-medium">¥</span>
              <span className="text-4xl font-bold">{balance.toFixed(2)}</span>
          </div>
          <div className="absolute -right-6 -bottom-6 opacity-20">
             <DollarSign size={120} />
          </div>
      </div>

      <div className="bg-white mx-4 rounded-xl flex flex-wrap p-4 shadow-sm">
         <div onClick={handleTopUp} className="w-1/3 flex flex-col items-center justify-center p-4 border-r border-b border-gray-100 cursor-pointer active:bg-gray-50">
             <DollarSign className="text-[#07C160] mb-2" size={28} />
             <span className="text-sm text-gray-700">充值</span>
         </div>
         <div className="w-1/3 flex flex-col items-center justify-center p-4 border-r border-b border-gray-100 cursor-pointer active:bg-gray-50">
             <CreditCard className="text-blue-500 mb-2" size={28} />
             <span className="text-sm text-gray-700">银行卡</span>
         </div>
         <div className="w-1/3 flex flex-col items-center justify-center p-4 border-b border-gray-100 cursor-pointer active:bg-gray-50">
             <GripHorizontal className="text-orange-500 mb-2" size={28} />
             <span className="text-sm text-gray-700">服务</span>
         </div>
      </div>
      
      <p className="text-center text-gray-400 text-xs mt-8">本服务由微信AI提供技术支持</p>
    </div>
  );
};

export default Wallet;