import React from 'react';
import { MessageSquare, Users, Compass, User } from 'lucide-react';
import { Tab } from '../types';
import { MockBackend } from '../services/mockBackend';

interface LayoutProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ activeTab, onTabChange, children }) => {
  const currentUser = MockBackend.getCurrentUser();
  const avatar = currentUser?.avatar || "https://picsum.photos/id/64/200/200";

  const navItems: { id: Tab; icon: React.ReactNode; label: string }[] = [
    { id: 'chat', icon: <MessageSquare size={24} />, label: '微信' },
    { id: 'contacts', icon: <Users size={24} />, label: '通讯录' },
    { id: 'discover', icon: <Compass size={24} />, label: '发现' },
    { id: 'me', icon: <User size={24} />, label: '我' },
  ];

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-white">
      {/* Desktop Sidebar (Leftmost vertical strip) */}
      <div className="hidden md:flex flex-col items-center w-20 bg-[#2e2e2e] py-6 space-y-8 flex-shrink-0">
        <div className="w-10 h-10 rounded-lg bg-gray-600 mb-4 overflow-hidden">
             <img src={avatar} alt="Me" className="w-full h-full object-cover" />
        </div>
        
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`p-2 rounded-xl transition-colors ${
              activeTab === item.id ? 'text-[#07C160]' : 'text-gray-400 hover:text-white'
            }`}
            title={item.label}
          >
            {item.icon}
          </button>
        ))}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden relative">
        {children}
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <div className="md:hidden absolute bottom-0 left-0 w-full h-[60px] bg-[#f7f7f7] border-t border-gray-300 flex justify-around items-center px-2 z-50">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center justify-center w-16 space-y-1 ${
              activeTab === item.id ? 'text-[#07C160]' : 'text-gray-500'
            }`}
          >
            <div className={activeTab === item.id ? 'text-[#07C160]' : 'text-gray-800'}>
                {item.icon}
            </div>
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Layout;
