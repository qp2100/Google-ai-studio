import React, { useState } from 'react';
import { User } from '../types';
import { MockBackend } from '../services/mockBackend';
import { UserPlus, Users, Trash2, X } from 'lucide-react';

interface ContactListProps {
  onSelectContact: (contactId: string) => void;
  currentUser: User;
}

const ContactList: React.FC<ContactListProps> = ({ onSelectContact, currentUser }) => {
  const [contacts, setContacts] = useState<User[]>(MockBackend.getContacts());
  const [showAddModal, setShowAddModal] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [newFriendName, setNewFriendName] = useState('');
  
  // Group creation state
  const [groupName, setGroupName] = useState('');
  const [selectedForGroup, setSelectedForGroup] = useState<string[]>([]);

  const handleAddFriend = async () => {
    if(!newFriendName) return;
    const exists = await MockBackend.addFriend(newFriendName);
    if(exists) {
        alert("好友已添加! (模拟刷新)");
        setContacts(MockBackend.getContacts());
        setShowAddModal(false);
    } else {
        alert("未找到用户 (试试 '马斯克' 或 '爱丽丝')");
    }
  };

  const handleDelete = (id: string) => {
     if(confirm("确定删除该联系人吗？")) {
         setContacts(prev => prev.filter(c => c.id !== id));
     }
  };

  const toggleGroupSelection = (id: string) => {
      setSelectedForGroup(prev => 
        prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
      );
  };

  const handleCreateGroup = async () => {
      if(!groupName || selectedForGroup.length === 0) return;
      
      const newChat = await MockBackend.createGroupChat(groupName, [currentUser.id, ...selectedForGroup]);
      
      setShowGroupModal(false);
      setGroupName('');
      setSelectedForGroup([]);
      
      // Navigate to the newly created chat
      onSelectContact(newChat.id);
  };

  return (
    <div className="h-full bg-white flex flex-col w-full relative">
        <div className="h-[60px] bg-[#f5f5f5] flex items-center justify-between px-4 border-b border-gray-300">
             <h2 className="text-lg font-bold text-gray-800">通讯录</h2>
             <button onClick={() => setShowAddModal(true)} className="text-gray-800"><UserPlus size={24}/></button>
        </div>
        
        <div className="overflow-y-auto flex-1 pb-20 md:pb-0">
             <div className="space-y-0">
                 {/* Special Items */}
                 <div className="flex items-center px-4 py-3 bg-white hover:bg-gray-100 cursor-pointer border-b border-gray-100" onClick={() => setShowGroupModal(true)}>
                     <div className="w-9 h-9 rounded bg-[#ededed] flex items-center justify-center mr-3">
                         <Users size={20} className="text-gray-600" />
                     </div>
                     <span className="text-gray-900 font-medium">群聊</span>
                 </div>
                 
                 {/* Contacts */}
                 <div className="mt-2">
                     <div className="px-4 py-1 bg-gray-100 text-xs text-gray-500">好友</div>
                     {contacts.map((contact) => (
                        <div key={contact.id} className="flex items-center justify-between px-4 py-3 hover:bg-gray-100 border-b border-gray-50 group">
                            <div className="flex items-center flex-1 cursor-pointer" onClick={() => onSelectContact(contact.id)}>
                                <div className="relative mr-3">
                                    <img src={contact.avatar} alt={contact.name} className={`w-9 h-9 rounded-md object-cover ${contact.isDeveloper ? 'ring-2 ring-yellow-400' : ''}`} />
                                </div>
                                <div>
                                    <span className={`text-gray-900 font-medium ${contact.isDeveloper ? 'text-yellow-600' : ''}`}>{contact.name}</span>
                                    {contact.isDeveloper && <span className="ml-2 text-[10px] bg-yellow-100 text-yellow-700 border border-yellow-200 px-1 rounded">《开发者》</span>}
                                    {contact.isBot && <span className="ml-2 text-[10px] bg-blue-100 text-blue-600 px-1 rounded">BOT</span>}
                                </div>
                            </div>
                            {!contact.isBot && !contact.isDeveloper && (
                                <button onClick={() => handleDelete(contact.id)} className="text-gray-300 hover:text-red-500">
                                    <Trash2 size={16} />
                                </button>
                            )}
                        </div>
                     ))}
                 </div>
             </div>
        </div>

        {/* Add Friend Modal */}
        {showAddModal && (
            <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                <div className="bg-white w-full max-w-sm rounded-lg p-6">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold">添加朋友</h3>
                        <button onClick={() => setShowAddModal(false)}><X /></button>
                    </div>
                    <input 
                        className="w-full border p-2 rounded mb-4" 
                        placeholder="通过用户名搜索" 
                        value={newFriendName}
                        onChange={(e) => setNewFriendName(e.target.value)}
                    />
                    <button onClick={handleAddFriend} className="w-full bg-[#07C160] text-white py-2 rounded">搜索并添加</button>
                </div>
            </div>
        )}

        {/* Create Group Modal */}
        {showGroupModal && (
            <div className="absolute inset-0 bg-white z-50 flex flex-col">
                <div className="h-[60px] flex items-center justify-between px-4 border-b">
                    <button onClick={() => setShowGroupModal(false)} className="text-gray-600">取消</button>
                    <h3 className="font-bold">发起群聊</h3>
                    <button 
                        onClick={handleCreateGroup} 
                        className={`text-[#07C160] font-bold ${(!groupName || selectedForGroup.length === 0) ? 'opacity-50' : ''}`}
                    >
                        完成
                    </button>
                </div>
                <div className="p-4 border-b">
                    <input 
                        className="w-full outline-none text-lg" 
                        placeholder="群名称" 
                        value={groupName}
                        onChange={(e) => setGroupName(e.target.value)}
                    />
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                    <p className="text-xs text-gray-500 mb-2">选择联系人</p>
                    {contacts.filter(c => !c.isBot).map(contact => (
                        <div key={contact.id} className="flex items-center py-2 border-b border-gray-50" onClick={() => toggleGroupSelection(contact.id)}>
                            <div className={`w-5 h-5 rounded-full border mr-3 flex items-center justify-center ${selectedForGroup.includes(contact.id) ? 'bg-[#07C160] border-[#07C160]' : 'border-gray-300'}`}>
                                {selectedForGroup.includes(contact.id) && <div className="w-2 h-2 bg-white rounded-full"></div>}
                            </div>
                            <img src={contact.avatar} className="w-8 h-8 rounded mr-2" />
                            <span>{contact.name}</span>
                        </div>
                    ))}
                </div>
            </div>
        )}
    </div>
  );
};

export default ContactList;