import React, { useState } from 'react';
import { MockBackend } from '../services/mockBackend';
import { User } from '../types';
import { ShieldAlert, X } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
  onAdminEnter: () => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin, onAdminEnter }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Admin Login States
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminId, setAdminId] = useState('');
  const [adminPwd, setAdminPwd] = useState('');
  const [adminError, setAdminError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      let user;
      if (isLogin) {
        user = await MockBackend.login(username, password);
        if (!user) throw new Error('用户名或密码错误');
      } else {
        user = await MockBackend.register(username, password);
      }
      onLogin(user);
    } catch (err: any) {
      setError(err.message || '发生错误');
    } finally {
      setLoading(false);
    }
  };

  const handleAdminSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      // Validate Admin Credentials - Updated to 2232 / 123 as requested
      if (adminId === '2232' && adminPwd === '123') {
          onAdminEnter();
      } else {
          setAdminError('管理员账号或密码错误');
      }
  };

  return (
    <div className="flex h-screen w-screen items-center justify-center bg-gray-100 bg-[url('https://picsum.photos/id/119/1920/1080')] bg-cover bg-center relative overflow-hidden">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
      
      {/* User Login Card */}
      <div className={`bg-white p-8 rounded-2xl shadow-2xl w-full max-w-md relative z-10 flex flex-col transition-all duration-300 ${showAdminLogin ? 'scale-95 opacity-50 blur-sm pointer-events-none' : 'scale-100 opacity-100'}`}>
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-[#07C160] rounded-xl flex items-center justify-center text-white text-2xl font-bold shadow-lg">
            We
          </div>
        </div>
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">
          {isLogin ? '微信登录' : '创建账号'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">用户名 / 账号ID</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#07C160] focus:border-transparent outline-none transition-all"
              placeholder="输入用户名或ID"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">密码</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#07C160] focus:border-transparent outline-none transition-all"
              placeholder="输入密码"
            />
          </div>

          {error && <div className="text-red-500 text-sm text-center">{error}</div>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#07C160] hover:bg-[#06ad56] text-white font-bold py-3 rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? '处理中...' : (isLogin ? '登录' : '注册')}
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-gray-600">
          {isLogin ? "没有账号？ " : "已有账号？ "}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-[#07C160] font-bold hover:underline"
          >
            {isLogin ? '去注册' : '去登录'}
          </button>
        </div>

        <div className="mt-8 border-t border-gray-100 pt-4 flex justify-center">
            <button 
                onClick={() => {
                    setShowAdminLogin(true);
                    setAdminError('');
                    setAdminId('');
                    setAdminPwd('');
                }}
                className="flex items-center text-xs text-gray-400 hover:text-gray-600 transition-colors"
            >
                <ShieldAlert size={12} className="mr-1" />
                后台管理系统
            </button>
        </div>
      </div>

      {/* Admin Login Modal Overlay */}
      {showAdminLogin && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4">
              {/* Backdrop */}
              <div 
                className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
                onClick={() => setShowAdminLogin(false)}
              ></div>
              
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm relative z-50 overflow-hidden animate-in fade-in zoom-in duration-200">
                  <div className="bg-[#1a1a1a] p-6 text-white flex justify-between items-start">
                      <div>
                          <h2 className="text-xl font-bold flex items-center gap-2">
                              <ShieldAlert size={20} />
                              后台验证
                          </h2>
                          <p className="text-gray-400 text-xs mt-1">仅限管理员访问</p>
                      </div>
                      <button 
                        onClick={() => setShowAdminLogin(false)}
                        className="text-gray-400 hover:text-white transition-colors"
                      >
                          <X size={20} />
                      </button>
                  </div>

                  <form onSubmit={handleAdminSubmit} className="p-8 space-y-6">
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">管理员账号</label>
                          <input
                              type="text"
                              autoFocus
                              value={adminId}
                              onChange={(e) => setAdminId(e.target.value)}
                              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#1a1a1a] focus:border-transparent outline-none transition-all"
                              placeholder="请输入账号 (2232)"
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">管理员密码</label>
                          <input
                              type="password"
                              value={adminPwd}
                              onChange={(e) => setAdminPwd(e.target.value)}
                              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#1a1a1a] focus:border-transparent outline-none transition-all"
                              placeholder="请输入密码"
                          />
                      </div>

                      {adminError && (
                          <div className="bg-red-50 text-red-500 text-xs p-3 rounded-lg text-center border border-red-100 font-bold">
                              {adminError}
                          </div>
                      )}

                      <button
                          type="submit"
                          className="w-full bg-[#1a1a1a] hover:bg-black text-white font-bold py-3 rounded-lg transition-colors shadow-lg"
                      >
                          验证并进入
                      </button>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};

export default Auth;