import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { MockBackend } from '../services/mockBackend';
import { Users, Wallet, LogOut, ArrowLeft, RefreshCw, Search, Plus, Trash2, Edit2, Ban, CheckCircle, X } from 'lucide-react';

interface AdminDashboardProps {
  onExit: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onExit }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  
  // -- Action States --
  // 'balance': Editing Balance (original feature)
  // 'edit': Editing Profile (new)
  // 'create': Creating User (new)
  const [editingMode, setEditingMode] = useState<'none' | 'balance' | 'edit' | 'create'>('none');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // Form States
  const [formData, setFormData] = useState<Partial<User>>({});

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = () => {
    setUsers(MockBackend.getAllUsers());
  };

  // --- Handlers ---

  const handleDeleteUser = (userId: string) => {
      if (confirm("确定要永久删除该用户吗？此操作不可恢复。")) {
          MockBackend.deleteUser(userId);
          loadUsers();
      }
  };

  const handleToggleBan = (user: User) => {
      const newStatus = !user.isBanned;
      const action = newStatus ? "禁言" : "解封";
      if (confirm(`确定要${action}用户 "${user.name}" 吗？`)) {
          MockBackend.updateUser(user.id, { isBanned: newStatus });
          loadUsers();
      }
  };

  const openCreateModal = () => {
      setEditingMode('create');
      setFormData({
          name: '',
          password: '123',
          walletBalance: 0,
          wxid: '',
          avatar: ''
      });
  };

  const openEditModal = (user: User) => {
      setEditingMode('edit');
      setSelectedUser(user);
      setFormData({ ...user });
  };

  const openBalanceModal = (user: User) => {
      setEditingMode('balance');
      setSelectedUser(user);
      setFormData({ walletBalance: user.walletBalance });
  };

  const handleSave = () => {
      if (editingMode === 'create') {
          if (!formData.name) return alert("用户名不能为空");
          MockBackend.createUser(formData);
      } else if (editingMode === 'edit' && selectedUser) {
          MockBackend.updateUser(selectedUser.id, formData);
      } else if (editingMode === 'balance' && selectedUser) {
          // For balance, we usually use updateBalance for transaction logs, but simple update here works too
          // But to be consistent with previous logic:
          const diff = (formData.walletBalance || 0) - (selectedUser.walletBalance || 0);
          MockBackend.updateBalance(selectedUser.id, diff);
      }

      setEditingMode('none');
      setSelectedUser(null);
      loadUsers();
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (u.wxid && u.wxid.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="flex h-screen w-screen bg-gray-100 font-sans">
      {/* Sidebar */}
      <div className="w-64 bg-[#1a1a1a] text-white flex flex-col shadow-2xl z-10">
        <div className="p-6 border-b border-gray-800">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <span className="bg-[#07C160] w-2 h-6 rounded"></span>
            后台管理
          </h1>
          <p className="text-xs text-gray-500 mt-2">WeChat AI Control Panel</p>
        </div>
        
        <div className="flex-1 py-4 space-y-2">
          <div className="px-4 py-3 bg-[#07C160] text-white flex items-center gap-3 rounded mx-2 shadow-lg">
            <Users size={20} />
            <span className="font-medium">用户管理</span>
          </div>
          <div className="px-4 py-3 text-gray-400 hover:text-white flex items-center gap-3 cursor-not-allowed mx-2">
            <Wallet size={20} />
            <span className="font-medium">财务报表 (待开发)</span>
          </div>
        </div>

        <div className="p-4 border-t border-gray-800">
          <button 
            onClick={onExit}
            className="flex items-center gap-2 text-gray-400 hover:text-white w-full px-2 py-2 transition-colors"
          >
            <ArrowLeft size={18} />
            返回应用
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Topbar */}
        <div className="bg-white h-16 border-b border-gray-200 flex items-center justify-between px-8 shadow-sm z-10">
            <h2 className="text-lg font-bold text-gray-800">用户列表 / 权限控制</h2>
            <div className="flex items-center gap-4">
                <div className="bg-gray-100 flex items-center px-3 py-2 rounded-lg w-64 border border-transparent focus-within:border-[#07C160] transition-colors">
                    <Search size={18} className="text-gray-400 mr-2" />
                    <input 
                        className="bg-transparent outline-none text-sm w-full"
                        placeholder="搜索用户名或WXID..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <button onClick={loadUsers} className="p-2 text-gray-500 hover:text-gray-800 bg-gray-100 rounded-lg">
                    <RefreshCw size={20} />
                </button>
                <button 
                    onClick={openCreateModal}
                    className="flex items-center gap-2 bg-[#07C160] text-white px-4 py-2 rounded-lg hover:bg-[#06ad56] shadow-sm transition-colors"
                >
                    <Plus size={18} />
                    <span>新增用户</span>
                </button>
            </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-y-auto p-8 bg-gray-50">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">用户</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">微信ID</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">当前余额</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">状态</th>
                            <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase text-right">操作</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {filteredUsers.map(user => (
                            <tr key={user.id} className="hover:bg-gray-50 transition-colors group">
                                <td className="px-6 py-4 flex items-center gap-3">
                                    <div className="relative">
                                        <img src={user.avatar} className="w-10 h-10 rounded-lg bg-gray-200 object-cover" />
                                        {user.isBanned && <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center"><Ban size={16} className="text-red-500"/></div>}
                                    </div>
                                    <div>
                                        <div className="font-medium text-gray-900 flex items-center gap-2">
                                            {user.name}
                                            {user.isBot && <span className="bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded text-[10px] font-bold">BOT</span>}
                                        </div>
                                        <div className="text-xs text-gray-400">{user.id}</div>
                                    </div>
                                </td>
                                <td className="px-6 py-4 text-sm text-gray-600 font-mono">
                                    {user.wxid || '-'}
                                </td>
                                <td className="px-6 py-4">
                                    <span className={`font-bold ${user.walletBalance && user.walletBalance > 0 ? 'text-[#07C160]' : 'text-gray-400'}`}>
                                        ¥ {(user.walletBalance || 0).toFixed(2)}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    {user.isBanned ? (
                                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                            <Ban size={12} className="mr-1" /> 已禁言
                                        </span>
                                    ) : (
                                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                            <CheckCircle size={12} className="mr-1" /> 正常
                                        </span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <div className="flex items-center justify-end gap-2 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button 
                                            onClick={() => openBalanceModal(user)}
                                            className="p-1.5 text-yellow-600 hover:bg-yellow-50 rounded"
                                            title="管理资金"
                                        >
                                            <Wallet size={16} />
                                        </button>
                                        <button 
                                            onClick={() => openEditModal(user)}
                                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                                            title="编辑资料"
                                        >
                                            <Edit2 size={16} />
                                        </button>
                                        <button 
                                            onClick={() => handleToggleBan(user)}
                                            className={`p-1.5 rounded ${user.isBanned ? 'text-green-600 hover:bg-green-50' : 'text-orange-600 hover:bg-orange-50'}`}
                                            title={user.isBanned ? "解封" : "禁言"}
                                        >
                                            {user.isBanned ? <CheckCircle size={16} /> : <Ban size={16} />}
                                        </button>
                                        <button 
                                            onClick={() => handleDeleteUser(user.id)}
                                            className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                                            title="删除用户"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {filteredUsers.length === 0 && (
                    <div className="p-12 text-center text-gray-400">
                        暂无用户数据
                    </div>
                )}
            </div>
        </div>

        {/* --- MODALS --- */}
        {editingMode !== 'none' && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all">
                    <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                        <h3 className="font-bold text-gray-800">
                            {editingMode === 'create' && '新增用户'}
                            {editingMode === 'edit' && '编辑用户资料'}
                            {editingMode === 'balance' && '资金管理'}
                        </h3>
                        <button onClick={() => setEditingMode('none')} className="text-gray-400 hover:text-gray-600">
                            <X size={20} />
                        </button>
                    </div>
                    
                    <div className="p-6 space-y-4">
                        {editingMode === 'balance' ? (
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">钱包余额 (¥)</label>
                                <div className="relative">
                                    <span className="absolute left-3 top-2.5 text-gray-500">¥</span>
                                    <input 
                                        type="number"
                                        value={formData.walletBalance}
                                        onChange={(e) => setFormData({...formData, walletBalance: parseFloat(e.target.value)})}
                                        className="w-full pl-8 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#07C160] outline-none"
                                        autoFocus
                                    />
                                </div>
                                <p className="text-xs text-gray-500 mt-2">提示：输入负数可扣除余额。</p>
                            </div>
                        ) : (
                            <>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">用户名</label>
                                    <input 
                                        type="text"
                                        value={formData.name}
                                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#07C160] outline-none"
                                        placeholder="例如：旅行者"
                                    />
                                </div>
                                {editingMode === 'create' && (
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">初始密码</label>
                                        <input 
                                            type="text"
                                            value={formData.password}
                                            onChange={(e) => setFormData({...formData, password: e.target.value})}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#07C160] outline-none"
                                        />
                                    </div>
                                )}
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">微信号 (WXID)</label>
                                    <input 
                                        type="text"
                                        value={formData.wxid}
                                        onChange={(e) => setFormData({...formData, wxid: e.target.value})}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#07C160] outline-none"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">头像 URL</label>
                                    <input 
                                        type="text"
                                        value={formData.avatar}
                                        onChange={(e) => setFormData({...formData, avatar: e.target.value})}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#07C160] outline-none"
                                        placeholder="https://..."
                                    />
                                </div>
                                {editingMode === 'create' && (
                                     <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">初始余额</label>
                                        <input 
                                            type="number"
                                            value={formData.walletBalance}
                                            onChange={(e) => setFormData({...formData, walletBalance: parseFloat(e.target.value)})}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#07C160] outline-none"
                                        />
                                    </div>
                                )}
                            </>
                        )}
                    </div>

                    <div className="px-6 py-4 bg-gray-50 flex justify-end gap-3">
                        <button 
                            onClick={() => setEditingMode('none')}
                            className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg transition-colors"
                        >
                            取消
                        </button>
                        <button 
                            onClick={handleSave}
                            className="px-4 py-2 bg-[#07C160] text-white rounded-lg hover:bg-[#06ad56] shadow-sm transition-colors font-medium"
                        >
                            保存更改
                        </button>
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;