import React, { useState, useEffect, useRef } from 'react';
import { Message, User, ChatSession } from '../types';
import { AI_BOT_ID } from '../constants';
import { MoreHorizontal, Smile, Mic, PlusCircle, Image as ImageIcon, Send, X, DollarSign, StopCircle, ArrowRightLeft, CheckCircle2, Users, Trash2, Plus } from 'lucide-react';
import { getGeminiChatResponseStream } from '../services/geminiService';
import { MockBackend } from '../services/mockBackend';

interface ChatWindowProps {
  chatId: string;
  chats: ChatSession[];
  setChats: React.Dispatch<React.SetStateAction<ChatSession[]>>;
  currentUser: User;
  onUpdateUser: (user: User) => void;
  onBack?: () => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ chatId, chats, setChats, currentUser, onUpdateUser, onBack }) => {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  
  // Transaction States
  const [transactionType, setTransactionType] = useState<'none' | 'redPacket' | 'transfer'>('none');
  const [transactionAmount, setTransactionAmount] = useState('');
  const [transferTarget, setTransferTarget] = useState<User | null>(null); 
  
  // Group Management States
  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [showMemberSelector, setShowMemberSelector] = useState<'transfer' | 'addMember' | 'none'>('none');

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const chatSession = chats.find(c => c.id === chatId);
  
  // Logic to find participant(s) name
  const getHeaderTitle = () => {
    if (!chatSession) return '';
    if (chatSession.isGroup) return chatSession.groupName || '群聊';
    const contacts = MockBackend.getContacts(); // Gets all users
    const participant = contacts.find(c => c.id === chatSession.participantId);
    return participant ? participant.name : '未知用户';
  };

  const getParticipant = (id: string): User => {
    const contacts = MockBackend.getContacts();
    if (id === currentUser.id) return currentUser;
    // Check if it's the Admin Account which might not be in standard contacts list initially if not added
    const allUsers = MockBackend.getAllUsers();
    return allUsers.find(c => c.id === id) || { 
        id: 'unknown', 
        name: '未知', 
        avatar: 'https://via.placeholder.com/40',
        isDeveloper: false
    } as User;
  };

  // Get all members for group selector
  const getGroupMembers = (): User[] => {
      if (!chatSession?.participantIds) return [];
      // Filter out current user from selection list
      return chatSession.participantIds
        .filter(id => id !== currentUser.id)
        .map(id => getParticipant(id));
  };
  
  // Get contacts NOT in the group (for adding members)
  const getNonGroupContacts = (): User[] => {
      const contacts = MockBackend.getContacts();
      if (!chatSession?.participantIds) return [];
      return contacts.filter(c => !chatSession.participantIds?.includes(c.id));
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatSession?.messages, isTyping, showPlusMenu]);

  if (!chatSession) return <div className="flex-1 bg-[#f5f5f5] flex items-center justify-center text-gray-400">未找到聊天</div>;

  // --- Ban Check ---
  const checkIsBanned = () => {
      if (currentUser.isBanned) {
          alert('您的账号已被管理员禁言，无法发送消息或进行操作。');
          return true;
      }
      return false;
  };

  // --- Message Sending Logic ---

  const sendMessage = async (type: Message['type'], content: string, mediaUrl?: string, extraConfig?: any) => {
    if (currentUser.isBanned) return;

    let displayContent = content;
    if (type === 'redPacket') displayContent = '[微信红包]';
    if (type === 'transfer') displayContent = `[转账] ¥${extraConfig?.amount}`;

    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: currentUser.id,
      text: displayContent,
      timestamp: Date.now(),
      type: type,
      mediaUrl: mediaUrl,
      redPacket: type === 'redPacket' ? extraConfig : undefined,
      transfer: type === 'transfer' ? extraConfig : undefined
    };

    const updatedChats = chats.map(c => {
      if (c.id === chatId) {
        return {
          ...c,
          messages: [...c.messages, newMsg],
          lastMessage: displayContent,
          lastMessageTime: Date.now(),
        };
      }
      return c;
    });
    setChats(updatedChats);
    MockBackend.saveChats(updatedChats);
    setInputText('');
    setShowPlusMenu(false);

    // AI Response logic
    if (chatSession.participantId === AI_BOT_ID) {
      setIsTyping(true);
      try {
        const history = chatSession.messages.map(m => ({
          role: m.senderId === currentUser.id ? 'user' as const : 'model' as const,
          parts: [{ text: m.text }]
        }));

        let prompt = content;
        if(type === 'image') prompt = "我发送了一张图片。";
        if(type === 'audio') prompt = "我发送了一条语音。";
        if(type === 'redPacket') prompt = `我发了一个 ${extraConfig.amount} 元的红包。`;
        if(type === 'transfer') prompt = `我转账给你 ${extraConfig.amount} 元。`;

        const stream = await getGeminiChatResponseStream(prompt, history);
        
        let aiResponseText = '';
        const tempBotMsgId = (Date.now() + 1).toString();
        
        setChats(prevChats => prevChats.map(c => {
          if (c.id === chatId) {
            return {
              ...c,
              messages: [...c.messages, {
                id: tempBotMsgId,
                senderId: AI_BOT_ID,
                text: '...',
                timestamp: Date.now(),
                type: 'text'
              }]
            };
          }
          return c;
        }));

        for await (const chunk of stream) {
            const chunkText = chunk.text || '';
            aiResponseText += chunkText;
            setChats(prevChats => prevChats.map(c => {
                if (c.id === chatId) {
                    const msgs = [...c.messages];
                    const lastMsg = msgs[msgs.length - 1];
                    if (lastMsg.id === tempBotMsgId) {
                        lastMsg.text = aiResponseText;
                    }
                    return { ...c, messages: msgs, lastMessage: aiResponseText, lastMessageTime: Date.now() };
                }
                return c;
            }));
        }
      } catch (e) {
        console.error("AI Error", e);
      } finally {
        setIsTyping(false);
      }
    }
  };

  // --- Handlers ---

  const handleTextSubmit = () => {
    if (checkIsBanned()) return;
    if (!inputText.trim()) return;
    sendMessage('text', inputText);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (checkIsBanned()) return;
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        sendMessage('image', '', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // --- Transaction Initiation Handlers ---

  const handleInitiateRedPacket = () => {
      setTransactionType('redPacket');
      setTransactionAmount('');
      setTransferTarget(null);
  };

  const handleInitiateTransfer = () => {
      if (chatSession.isGroup) {
          setShowMemberSelector('transfer');
      } else {
          const p = getParticipant(chatSession.participantId!);
          setTransferTarget(p);
          setTransactionType('transfer');
          setTransactionAmount('');
      }
  };

  const handleSelectGroupMemberForTransfer = (member: User) => {
      setTransferTarget(member);
      setShowMemberSelector('none');
      setTransactionType('transfer');
      setTransactionAmount('');
  };

  // --- Group Management Handlers ---

  const handleAddMemberToGroup = (member: User) => {
      const updatedChats = MockBackend.addGroupMember(chatId, member.id);
      setChats(updatedChats);
      setShowMemberSelector('none');
  };

  const handleDissolveGroup = () => {
      if(confirm("确定要解散并删除该群聊吗？")) {
          MockBackend.deleteChat(chatId);
          if (onBack) onBack(); // Go back to list on mobile
          // For desktop, usually parent handles list update, we just need to ensure selected ID is cleared
          window.location.reload(); // Simple way to reset view for this demo
      }
  };

  // --- Transaction Execution Handlers ---

  const confirmTransaction = () => {
      if (checkIsBanned()) return;
      const val = parseFloat(transactionAmount);
      
      if (isNaN(val) || val <= 0) {
          alert("请输入有效的金额");
          return;
      }
      
      if (currentUser.walletBalance === undefined || currentUser.walletBalance < val) {
          alert(`余额不足！当前余额: ¥${(currentUser.walletBalance || 0).toFixed(2)}`);
          return;
      }

      MockBackend.updateBalance(currentUser.id, -val);
      onUpdateUser({ ...currentUser, walletBalance: (currentUser.walletBalance || 0) - val });

      if (transactionType === 'redPacket') {
          sendMessage('redPacket', '大吉大利，今晚吃鸡！', undefined, { amount: val, status: 'unclaimed' });
      } else if (transactionType === 'transfer') {
          const recipientName = transferTarget ? transferTarget.name : "对方";
          const recipientId = transferTarget ? transferTarget.id : undefined;

          sendMessage('transfer', `转账给 ${recipientName}`, undefined, { 
             amount: val, 
             status: 'pending',
             description: `转账给 ${recipientName}`,
             recipientId: recipientId
          });
      }

      setTransactionType('none');
      setTransactionAmount('');
      setTransferTarget(null);
  };

  const handleClaimRedPacket = (msg: Message) => {
    if (checkIsBanned()) return;
    if (msg.redPacket?.status === 'unclaimed') {
        const amount = msg.redPacket.amount;
        MockBackend.updateBalance(currentUser.id, amount);
        onUpdateUser({ ...currentUser, walletBalance: (currentUser.walletBalance || 0) + amount });
        
        const updatedChats = chats.map(c => {
            if (c.id === chatId) {
                const newMsgs = c.messages.map(m => {
                    if (m.id === msg.id) {
                        return { ...m, redPacket: { ...m.redPacket!, status: 'claimed' as const, claimedBy: currentUser.id } };
                    }
                    return m;
                });
                return { ...c, messages: newMsgs };
            }
            return c;
        });
        setChats(updatedChats);
        MockBackend.saveChats(updatedChats);
        alert(`你领取了 ${amount.toFixed(2)} 元!`);
    } else {
        alert("红包已被领取！");
    }
  };

  const handleAcceptTransfer = (msg: Message) => {
    if (checkIsBanned()) return;
    
    if (msg.senderId === currentUser.id) {
        let statusText = "等待收款";
        if (msg.transfer?.status === 'accepted') statusText = "已收款";
        alert(`${statusText} (转账金额: ¥${msg.transfer?.amount.toFixed(2)})`);
        return;
    }

    if (msg.transfer?.recipientId && msg.transfer.recipientId !== currentUser.id) {
        alert("您不是该转账的指定接收人，无法领取。");
        return;
    }

    if (msg.transfer?.status === 'pending') {
        const amount = msg.transfer.amount;
        MockBackend.updateBalance(currentUser.id, amount);
        onUpdateUser({ ...currentUser, walletBalance: (currentUser.walletBalance || 0) + amount });

        const updatedChats = chats.map(c => {
            if (c.id === chatId) {
                const newMsgs = c.messages.map(m => {
                    if (m.id === msg.id) {
                        return { ...m, transfer: { ...m.transfer!, status: 'accepted' as const } };
                    }
                    return m;
                });
                return { ...c, messages: newMsgs };
            }
            return c;
        });
        setChats(updatedChats);
        MockBackend.saveChats(updatedChats);
        alert(`已确认收款 ¥${amount.toFixed(2)}`);
    } else {
        alert("该笔转账已收款");
    }
  };

  // --- Voice Recording ---
  const startRecording = async () => {
    if (checkIsBanned()) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
           sendMessage('audio', '', reader.result as string);
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      alert("无法访问麦克风");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // --- Render ---

  return (
    <div className="flex flex-col h-full bg-[#f5f5f5] w-full relative">
      {/* Header */}
      <div className="h-[60px] border-b border-gray-300 flex items-center justify-between px-4 bg-[#f5f5f5] shrink-0 z-10">
        <div className="flex items-center">
            {onBack && (
                <button onClick={onBack} className="mr-3 md:hidden text-gray-600">
                     <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
                </button>
            )}
            <h2 className="text-lg font-bold text-gray-800">{getHeaderTitle()} {chatSession.isGroup && `(${chatSession.participantIds?.length || 0})`}</h2>
        </div>
        <button onClick={() => setShowGroupInfo(true)} className="text-gray-600 hover:bg-gray-200 p-2 rounded-full">
            <MoreHorizontal size={24} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 md:pb-4 pb-20 scrollbar-hide">
        {chatSession.messages.map((msg) => {
          const isMe = msg.senderId === currentUser.id;
          const sender = isMe ? currentUser : getParticipant(msg.senderId);
          // System message check
          if (msg.senderId === 'system') {
              return (
                  <div key={msg.id} className="flex justify-center my-2">
                      <span className="text-xs text-gray-400 bg-gray-200 px-2 py-1 rounded">{msg.text}</span>
                  </div>
              )
          }

          return (
            <div key={msg.id} className={`flex w-full ${isMe ? 'justify-end' : 'justify-start'}`}>
              {!isMe && (
                <div className="relative mr-2 self-start group">
                    <img 
                        src={sender.avatar} 
                        alt="Sender" 
                        className={`w-9 h-9 rounded-md bg-white object-cover ${sender.isDeveloper ? 'ring-2 ring-yellow-400' : ''}`} 
                    />
                </div>
              )}
              
              <div className="flex flex-col max-w-[80%]">
                 {!isMe && chatSession.isGroup && <span className="text-xs text-gray-400 mb-1 ml-1">{sender.name}</span>}
                 {!isMe && !chatSession.isGroup && sender.isDeveloper && (
                     <span className="text-[10px] text-yellow-600 font-bold mb-1 ml-1 flex items-center gap-1">
                         {sender.name} <span className="bg-yellow-100 px-1 rounded border border-yellow-200">《开发者》</span>
                     </span>
                 )}
                 
                 {/* Content Bubble */}
                 <div
                    className={`px-3 py-2 rounded-lg text-sm leading-6 relative shadow-sm ${
                        msg.type === 'redPacket' 
                            ? 'bg-[#fa9d3b] text-white w-64 p-0 overflow-hidden cursor-pointer' 
                        : msg.type === 'transfer'
                            ? 'bg-[#ff9c34] text-white w-64 p-0 overflow-hidden cursor-pointer'
                        : isMe ? 'bg-[#95ec69] text-black' : 'bg-white text-gray-900 border border-gray-200'
                    }`}
                    onClick={() => {
                        if (msg.type === 'redPacket') handleClaimRedPacket(msg);
                        if (msg.type === 'transfer') handleAcceptTransfer(msg);
                    }}
                 >
                    {/* Triangle for text */}
                    {msg.type === 'text' && <div className={`absolute top-3 w-0 h-0 border-solid border-4 border-transparent ${isMe ? 'border-l-[#95ec69] -right-2' : 'border-r-white -left-2'}`} />}

                    {/* TEXT */}
                    {msg.type === 'text' && <span className="break-words">{msg.text}</span>}

                    {/* IMAGE */}
                    {msg.type === 'image' && (
                        <img src={msg.mediaUrl} alt="sent" className="rounded-lg max-h-60 max-w-full" />
                    )}

                    {/* AUDIO */}
                    {msg.type === 'audio' && (
                        <div className="flex items-center space-x-2 min-w-[100px]">
                            <Mic size={16} />
                            <span>语音消息</span>
                            <audio src={msg.mediaUrl} controls className="hidden" id={`audio-${msg.id}`} />
                            <button onClick={() => (document.getElementById(`audio-${msg.id}`) as HTMLAudioElement)?.play()} className="absolute inset-0"></button>
                        </div>
                    )}

                    {/* RED PACKET */}
                    {msg.type === 'redPacket' && (
                        <div className="flex flex-col">
                            <div className="flex items-center p-3.5">
                                <div className="bg-[#fbdb76] rounded p-2 mr-3 text-[#fa9d3b] shrink-0">
                                    <DollarSign size={24} />
                                </div>
                                <div className="flex flex-col text-white overflow-hidden">
                                    <span className="font-bold truncate text-[15px]">{msg.redPacket?.status === 'claimed' ? '红包已领取' : '恭喜发财，大吉大利'}</span>
                                    <span className="text-xs opacity-80">{msg.redPacket?.status === 'claimed' ? '查看详情' : '领取红包'}</span>
                                </div>
                            </div>
                            <div className="bg-white/10 px-3.5 py-1 text-xs text-white/70">
                                微信红包
                            </div>
                        </div>
                    )}

                    {/* TRANSFER */}
                    {msg.type === 'transfer' && (
                        <div className="flex flex-col">
                            <div className="flex items-start p-3.5">
                                <div className="bg-white/20 rounded-full p-2 mr-3 text-white shrink-0">
                                    {msg.transfer?.status === 'accepted' ? <CheckCircle2 size={24} /> : <ArrowRightLeft size={24} />}
                                </div>
                                <div className="flex flex-col text-white overflow-hidden">
                                    <span className="text-[15px] font-bold">¥{msg.transfer?.amount.toFixed(2)}</span>
                                    <span className="text-xs opacity-90 mt-0.5">
                                        {msg.transfer?.status === 'accepted' ? '已收款' : msg.transfer?.description}
                                    </span>
                                </div>
                            </div>
                            <div className="bg-white/10 px-3.5 py-1 text-xs text-white/70">
                                微信转账
                            </div>
                        </div>
                    )}
                 </div>
              </div>

              {isMe && (
                <div className="relative ml-2 self-start">
                    <img 
                        src={currentUser.avatar} 
                        alt="Me" 
                        className={`w-9 h-9 rounded-md object-cover ${currentUser.isDeveloper ? 'ring-2 ring-yellow-400' : ''}`}
                    />
                </div>
              )}
            </div>
          );
        })}
        
        {isTyping && (
             <div className="flex w-full justify-start">
                 <img src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Google_Gemini_logo.svg" className="w-9 h-9 rounded-md mr-2 self-start bg-white p-1" />
                 <div className="bg-white text-gray-500 px-3 py-2 rounded-lg text-sm border border-gray-200">
                     正在输入...
                 </div>
             </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-[#f5f5f5] border-t border-gray-300 px-3 py-2 shrink-0 mb-[60px] md:mb-0">
        <div className="flex items-center space-x-3 h-10">
             <button 
                onMouseDown={startRecording}
                onMouseUp={stopRecording}
                onTouchStart={startRecording}
                onTouchEnd={stopRecording}
                className={`p-1 rounded-full border ${isRecording ? 'bg-red-500 text-white border-red-500' : 'text-gray-600 border-gray-400'}`}
             >
                {isRecording ? <StopCircle size={24} /> : <Mic size={24} />}
             </button>
             
             <div className="flex-1">
                 <input
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleTextSubmit()}
                    className="w-full bg-white border border-gray-200 rounded px-3 py-2 text-sm focus:outline-none h-9"
                    placeholder={currentUser.isBanned ? "您已被禁言" : (isRecording ? "松开 发送" : "")}
                    disabled={isRecording || currentUser.isBanned}
                 />
             </div>

             <button className="text-gray-600"><Smile size={26} /></button>
             
             {inputText.length > 0 ? (
                 <button onClick={handleTextSubmit} className="bg-[#07C160] text-white px-3 py-1.5 rounded text-sm font-medium">发送</button>
             ) : (
                 <button onClick={() => setShowPlusMenu(!showPlusMenu)} className="text-gray-600">
                    {showPlusMenu ? <X size={26} /> : <PlusCircle size={26} />}
                 </button>
             )}
        </div>

        {/* Plus Menu - Drawer */}
        {showPlusMenu && (
            <div className="grid grid-cols-4 gap-4 pt-4 pb-2 border-t border-gray-200 mt-2 bg-[#f5f5f5]">
                <div className="flex flex-col items-center space-y-2 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                    <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center border border-gray-200">
                        <ImageIcon size={28} className="text-gray-500" />
                    </div>
                    <span className="text-xs text-gray-500">照片</span>
                    <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handleImageUpload} />
                </div>
                <div className="flex flex-col items-center space-y-2 cursor-pointer" onClick={handleInitiateRedPacket}>
                    <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center border border-gray-200">
                        <DollarSign size={28} className="text-red-500" />
                    </div>
                    <span className="text-xs text-gray-500">红包</span>
                </div>
                <div className="flex flex-col items-center space-y-2 cursor-pointer" onClick={handleInitiateTransfer}>
                    <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center border border-gray-200">
                        <ArrowRightLeft size={28} className="text-orange-500" />
                    </div>
                    <span className="text-xs text-gray-500">转账</span>
                </div>
                <div className="flex flex-col items-center space-y-2 cursor-pointer">
                    <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center border border-gray-200">
                        <div className="w-6 h-6 bg-gray-300 rounded-full"></div>
                    </div>
                    <span className="text-xs text-gray-500">拍摄</span>
                </div>
            </div>
        )}
      </div>

      {/* Member Selector Modal (Generic: for Transfer or Adding Member) */}
      {showMemberSelector !== 'none' && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50">
              <div className="bg-white w-full max-w-sm rounded-lg flex flex-col max-h-[80%] overflow-hidden animate-in zoom-in-95 duration-200">
                  <div className="flex justify-between items-center p-4 border-b">
                      <h3 className="font-bold text-lg">
                          {showMemberSelector === 'transfer' ? '选择转账接收人' : '邀请新成员'}
                      </h3>
                      <button onClick={() => setShowMemberSelector('none')} className="text-gray-500"><X /></button>
                  </div>
                  <div className="overflow-y-auto flex-1 p-2">
                      {/* Show Group Members (Transfer) OR Non-Members (Add) */}
                      {(showMemberSelector === 'transfer' ? getGroupMembers() : getNonGroupContacts()).map(member => (
                          <div 
                              key={member.id} 
                              onClick={() => showMemberSelector === 'transfer' ? handleSelectGroupMemberForTransfer(member) : handleAddMemberToGroup(member)}
                              className="flex items-center p-3 hover:bg-gray-100 rounded-lg cursor-pointer"
                          >
                              <img src={member.avatar} className="w-10 h-10 rounded-lg bg-gray-200 mr-3 object-cover" />
                              <span className="font-medium text-gray-800">{member.name}</span>
                          </div>
                      ))}
                      {(showMemberSelector === 'transfer' ? getGroupMembers() : getNonGroupContacts()).length === 0 && (
                          <div className="text-center text-gray-400 py-8">无可用成员</div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {/* Group Info Drawer (Settings) */}
      {showGroupInfo && (
          <div className="absolute inset-0 z-40 bg-gray-100 flex flex-col animate-in slide-in-from-right duration-200">
              <div className="h-[60px] flex items-center px-4 bg-white border-b border-gray-200">
                  <button onClick={() => setShowGroupInfo(false)} className="mr-3">
                     <svg className="w-6 h-6 text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
                  </button>
                  <span className="font-bold text-lg">聊天信息 ({chatSession.participantIds?.length || 2})</span>
              </div>
              
              <div className="flex-1 overflow-y-auto">
                  {/* Member Grid */}
                  <div className="bg-white p-4 mt-2 grid grid-cols-5 gap-y-4">
                      {/* Self */}
                      <div className="flex flex-col items-center">
                          <img src={currentUser.avatar} className="w-12 h-12 rounded bg-gray-200 mb-1 object-cover" />
                          <span className="text-xs text-gray-500 truncate w-14 text-center">{currentUser.name}</span>
                      </div>
                      {/* Other Members */}
                      {getGroupMembers().map(m => (
                          <div key={m.id} className="flex flex-col items-center">
                              <img src={m.avatar} className="w-12 h-12 rounded bg-gray-200 mb-1 object-cover" />
                              <span className="text-xs text-gray-500 truncate w-14 text-center">{m.name}</span>
                          </div>
                      ))}
                      {/* Add Button */}
                      {chatSession.isGroup && (
                          <div className="flex flex-col items-center cursor-pointer" onClick={() => setShowMemberSelector('addMember')}>
                              <div className="w-12 h-12 rounded border-2 border-gray-300 border-dashed flex items-center justify-center text-gray-400 mb-1">
                                  <Plus size={24} />
                              </div>
                              <span className="text-xs text-gray-400">添加</span>
                          </div>
                      )}
                  </div>

                  {/* Settings List */}
                  <div className="mt-2 bg-white">
                      <div className="flex justify-between items-center p-4 border-b border-gray-100">
                          <span className="text-gray-900">群聊名称</span>
                          <span className="text-gray-500 text-sm">{chatSession.groupName || '未命名'}</span>
                      </div>
                      <div className="flex justify-between items-center p-4 border-b border-gray-100">
                          <span className="text-gray-900">查找聊天记录</span>
                          <span className="text-gray-400"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg></span>
                      </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-4 bg-white">
                       <button 
                            onClick={handleDissolveGroup}
                            className="w-full py-3 text-red-500 font-bold text-center active:bg-gray-100"
                        >
                           {chatSession.isGroup ? '删除并退出群聊' : '删除聊天'}
                       </button>
                  </div>
              </div>
          </div>
      )}

      {/* Transaction Modal Overlay */}
      {transactionType !== 'none' && (
          <div className="absolute inset-0 z-50 flex items-end md:items-center justify-center bg-black/50">
              <div className="bg-[#f5f5f5] w-full md:w-[320px] rounded-t-xl md:rounded-xl overflow-hidden animate-in slide-in-from-bottom duration-200">
                  <div className="bg-[#ededed] p-4 flex justify-between items-center relative">
                      <button onClick={() => setTransactionType('none')} className="text-gray-600">取消</button>
                      <h3 className="font-bold">{transactionType === 'redPacket' ? '发红包' : '转账'}</h3>
                      <div className="w-8"></div>
                  </div>
                  <div className="p-6">
                      {/* Show who we are transferring to if applicable */}
                      {transactionType === 'transfer' && transferTarget && (
                          <div className="flex flex-col items-center mb-6">
                              <img src={transferTarget.avatar} className="w-12 h-12 rounded-lg mb-2 object-cover" />
                              <span className="text-gray-600 text-sm">转账给 {transferTarget.name}</span>
                              <span className="text-gray-400 text-xs">{transferTarget.wxid || transferTarget.id}</span>
                          </div>
                      )}

                      <div className="bg-white p-4 rounded-lg flex items-center mb-4">
                          <span className="text-gray-900 font-bold mr-2">金额</span>
                          <input 
                            type="number" 
                            className="flex-1 text-right outline-none text-xl font-bold placeholder-gray-300" 
                            placeholder="0.00"
                            value={transactionAmount}
                            onChange={(e) => setTransactionAmount(e.target.value)}
                            autoFocus
                          />
                          <span className="ml-2 text-gray-900">元</span>
                      </div>
                      <div className="text-center mb-6">
                           <span className="text-3xl font-bold">¥{transactionAmount || '0.00'}</span>
                      </div>
                      <button 
                        onClick={confirmTransaction}
                        className={`w-full py-3 rounded-lg font-bold text-white transition-colors ${transactionType === 'redPacket' ? 'bg-[#fa9d3b] hover:bg-[#e68d32]' : 'bg-[#07C160] hover:bg-[#06ad56]'}`}
                      >
                          {transactionType === 'redPacket' ? '塞钱进红包' : '确认转账'}
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default ChatWindow;