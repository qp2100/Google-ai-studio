import React, { useState, useRef, useEffect } from 'react';
import { User } from '../types';
import { ChevronRight, Settings, Image, Smile, Wallet as WalletIcon, Check, Edit2, Camera, Download } from 'lucide-react';
import Wallet from './Wallet';
import { MockBackend } from '../services/mockBackend';

interface ProfileProps {
    currentUser: User;
    onUpdateUser: (updatedUser: User) => void;
    onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ currentUser, onUpdateUser, onLogout }) => {
  const [showWallet, setShowWallet] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const [editName, setEditName] = useState(currentUser.name);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Check if running in standalone mode (installed)
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone) {
        setIsInstalled(true);
    }

    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallClick = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the install prompt');
        }
        setDeferredPrompt(null);
      });
    } else {
        alert("请在浏览器菜单中点击 '添加到主屏幕' 或 '安装应用'。");
    }
  };

  const handleNameSave = () => {
      const updated = MockBackend.updateUser(currentUser.id, { name: editName });
      if (updated) {
          onUpdateUser(updated);
          setIsEditingName(false);
      }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const base64 = reader.result as string;
              const updated = MockBackend.updateUser(currentUser.id, { avatar: base64 });
              if (updated) {
                  onUpdateUser(updated);
              }
          };
          reader.readAsDataURL(file);
      }
  };

  if (showWallet) {
      return (
        <Wallet 
            onBack={() => setShowWallet(false)} 
            currentUser={currentUser} 
            onUpdateUser={onUpdateUser}
        />
      );
  }

  return (
    <div className="h-full bg-[#f5f5f5] w-full overflow-y-auto pb-20 md:pb-0">
        <div className="bg-white p-6 md:p-10 flex items-center mb-2 mt-4 md:mt-0 relative">
            <div className="relative cursor-pointer group" onClick={() => fileInputRef.current?.click()}>
                <img 
                    src={currentUser.avatar} 
                    alt="Me" 
                    className={`w-16 h-16 rounded-lg mr-4 bg-gray-200 object-cover ${currentUser.isDeveloper ? 'ring-4 ring-yellow-400' : ''}`} 
                />
                <div className="absolute inset-0 bg-black/30 rounded-lg opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity w-16 h-16">
                    <Camera size={20} />
                </div>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
            </div>

            <div className="flex-1">
                <div className="flex items-center">
                    {isEditingName ? (
                        <div className="flex items-center">
                            <input 
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                className="border border-gray-300 rounded px-2 py-1 text-lg font-bold w-32 mr-2"
                                autoFocus
                            />
                            <button onClick={handleNameSave} className="text-[#07C160]"><Check size={20} /></button>
                        </div>
                    ) : (
                        <div className="flex flex-col items-start">
                             <div className="flex items-center">
                                 <h2 className={`text-xl font-bold mr-2 ${currentUser.isDeveloper ? 'text-yellow-600' : 'text-gray-900'}`}>{currentUser.name}</h2>
                                 <button onClick={() => setIsEditingName(true)} className="text-gray-400 hover:text-gray-600">
                                     <Edit2 size={14} />
                                 </button>
                             </div>
                             {currentUser.isDeveloper && <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full border border-yellow-200 font-bold mb-1">《开发者》</span>}
                        </div>
                    )}
                </div>
                <p className="text-gray-500 text-sm mt-1">微信号: {currentUser.wxid || currentUser.id}</p>
            </div>
            <ChevronRight className="text-gray-400" />
        </div>

        <div className="space-y-2">
            <div className="bg-white">
                <div 
                    className="flex items-center px-4 py-4 border-b border-gray-100 cursor-pointer active:bg-gray-100"
                    onClick={() => setShowWallet(true)}
                >
                    <WalletIcon className="text-[#07C160] mr-4" size={24} />
                    <span className="flex-1 text-gray-900">支付 / 钱包</span>
                    <span className="text-xs text-gray-400 mr-2">¥{currentUser.walletBalance?.toFixed(2)}</span>
                    <ChevronRight className="text-gray-400" size={20} />
                </div>
            </div>

            <div className="bg-white">
                <div className="flex items-center px-4 py-4 border-b border-gray-100 cursor-pointer active:bg-gray-100">
                    <Image className="text-blue-500 mr-4" size={24} />
                    <span className="flex-1 text-gray-900">收藏</span>
                    <ChevronRight className="text-gray-400" size={20} />
                </div>
                 <div className="flex items-center px-4 py-4 border-b border-gray-100 cursor-pointer active:bg-gray-100">
                    <Image className="text-blue-400 mr-4" size={24} />
                    <span className="flex-1 text-gray-900">朋友圈</span>
                    <ChevronRight className="text-gray-400" size={20} />
                </div>
                 <div className="flex items-center px-4 py-4 border-b border-gray-100 cursor-pointer active:bg-gray-100">
                    <Smile className="text-yellow-500 mr-4" size={24} />
                    <span className="flex-1 text-gray-900">表情</span>
                    <ChevronRight className="text-gray-400" size={20} />
                </div>
            </div>

            <div className="bg-white">
                {!isInstalled && deferredPrompt && (
                    <div 
                        className="flex items-center px-4 py-4 border-b border-gray-100 cursor-pointer active:bg-gray-100"
                        onClick={handleInstallClick}
                    >
                        <Download className="text-green-600 mr-4" size={24} />
                        <span className="flex-1 text-gray-900">下载 / 安装应用</span>
                        <ChevronRight className="text-gray-400" size={20} />
                    </div>
                )}
                <div className="flex items-center px-4 py-4 border-b border-gray-100 cursor-pointer active:bg-gray-100">
                    <Settings className="text-blue-600 mr-4" size={24} />
                    <span className="flex-1 text-gray-900">设置</span>
                    <ChevronRight className="text-gray-400" size={20} />
                </div>
            </div>
            
            <button 
                onClick={onLogout}
                className="w-full bg-white py-4 text-center text-red-500 font-medium mt-2 hover:bg-gray-50"
            >
                退出登录
            </button>
        </div>
    </div>
  );
};

export default Profile;