import React from 'react';
import { ChatSession, User } from '../types';
import { MockBackend } from '../services/mockBackend';

interface ChatListProps {
  chats: ChatSession[];
  activeChatId: string | null;
  onSelectChat: (chatId: string) => void;
  className?: string;
}

const ChatList: React.FC<ChatListProps> = ({ chats, activeChatId, onSelectChat, className = '' }) => {
  const getContact = (id: string) => {
      const contacts = MockBackend.getContacts();
      // Also check bots or self if needed, though contacts usually has all
      return contacts.find((c) => c.id === id) || { name: '未知用户', avatar: '' };
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    if (date.toDateString() === now.toDateString()) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className={`h-full flex flex-col bg-[#e6e6e6] border-r border-gray-200 overflow-y-auto ${className}`}>
        {/* Search Bar */}
        <div className="p-4 bg-[#f5f5f5] sticky top-0 z-10">
            <div className="flex items-center bg-white rounded-md px-3 py-1.5 border border-gray-300">
                <svg className="w-4 h-4 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                <input type="text" placeholder="搜索" className="bg-transparent border-none outline-none text-sm w-full placeholder-gray-400" />
            </div>
        </div>

      <div className="flex-1">
        {chats.map((chat) => {
          // Use UI Avatars for group chats as a better default
          const contact = chat.isGroup 
            ? { 
                name: chat.groupName || '群聊', 
                avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(chat.groupName || '群')}&background=random&color=fff&rounded=true` 
              } 
            : getContact(chat.participantId!);
          
          const isActive = activeChatId === chat.id;

          return (
            <div
              key={chat.id}
              onClick={() => onSelectChat(chat.id)}
              className={`flex items-center p-3 cursor-pointer hover:bg-[#dcdcdc] transition-colors ${
                isActive ? 'bg-[#c5c5c5] hover:bg-[#c5c5c5]' : ''
              }`}
            >
              <div className="relative">
                <img
                  src={contact.avatar || 'https://via.placeholder.com/50'}
                  alt={contact.name}
                  className="w-12 h-12 rounded-lg object-cover bg-white"
                />
                {chat.unreadCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center border-2 border-[#e6e6e6]">
                    {chat.unreadCount}
                  </span>
                )}
              </div>
              
              <div className="ml-3 flex-1 min-w-0">
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="text-sm font-semibold text-gray-900 truncate">{contact.name}</h3>
                  <span className="text-xs text-gray-400 whitespace-nowrap ml-2">
                    {formatTime(chat.lastMessageTime)}
                  </span>
                </div>
                <p className="text-sm text-gray-500 truncate">{chat.lastMessage}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ChatList;