import React, { useState, useRef } from 'react';
import { Camera, MessageCircle, Heart, Image as ImageIcon, X, Send } from 'lucide-react';
import { CURRENT_USER, CONTACTS } from '../constants';
import { Moment } from '../types';
import { MockBackend } from '../services/mockBackend';

const Moments: React.FC = () => {
  const [moments, setMoments] = useState<Moment[]>(MockBackend.getMoments());
  const [showPublish, setShowPublish] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [newImage, setNewImage] = useState<string | null>(null);
  const [showCommentInput, setShowCommentInput] = useState<string | null>(null); // Moment ID
  const [commentText, setCommentText] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentUser = MockBackend.getCurrentUser() || CURRENT_USER;

  const getUser = (id: string) => {
    const contacts = MockBackend.getContacts();
    if (id === currentUser.id) return currentUser;
    return contacts.find((c) => c.id === id) || { name: '未知', avatar: 'https://via.placeholder.com/40' };
  };

  const getTimeAgo = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    if (hours > 24) return Math.floor(hours / 24) + ' 天前';
    if (hours > 0) return hours + ' 小时前';
    if (minutes > 0) return minutes + ' 分钟前';
    return '刚刚';
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const checkIsBanned = () => {
      if (currentUser.isBanned) {
          alert("您已被禁言，无法发布动态。");
          return true;
      }
      return false;
  };

  const handleOpenPublish = () => {
      if (!checkIsBanned()) {
          setShowPublish(true);
      }
  };

  const handlePublish = () => {
      if (!newContent && !newImage) return;
      
      const images = newImage ? [newImage] : [];
      MockBackend.addMoment(currentUser.id, newContent, images);
      
      // Reset and refresh
      setNewContent('');
      setNewImage(null);
      setShowPublish(false);
      setMoments(MockBackend.getMoments());
  };

  const handleLike = (id: string) => {
      MockBackend.toggleLike(id, currentUser.id);
      setMoments(MockBackend.getMoments());
  };

  const handleComment = (id: string) => {
      if (!commentText.trim()) return;
      MockBackend.addComment(id, currentUser.id, currentUser.name, commentText);
      setCommentText('');
      setShowCommentInput(null);
      setMoments(MockBackend.getMoments());
  };

  return (
    <div className="flex flex-col h-full bg-white overflow-y-auto w-full pb-20 md:pb-0 relative">
      {/* Header Image */}
      <div className="relative h-64 bg-gray-800 shrink-0">
        <img
          src="https://picsum.photos/id/1015/800/400"
          alt="Cover"
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute -bottom-6 right-4 flex items-end space-x-3">
            <span className="text-white font-bold text-lg mb-8 shadow-black drop-shadow-md">{currentUser.name}</span>
            <img
                src={currentUser.avatar}
                alt="Me"
                className="w-20 h-20 rounded-xl border-2 border-white object-cover bg-white"
            />
        </div>
      </div>

      <div className="pt-10 px-4 max-w-2xl mx-auto w-full space-y-8">
          {/* Header Action */}
          <div className="flex justify-end pr-2 -mt-6 mb-4">
               <Camera className="text-gray-800 cursor-pointer" size={24} onClick={handleOpenPublish} />
          </div>

        {moments.map((moment) => {
          const user = getUser(moment.userId);
          const isLiked = moment.likedBy.includes(currentUser.id);
          
          return (
            <div key={moment.id} className="flex space-x-3 border-b border-gray-100 pb-6">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
              />
              <div className="flex-1">
                <h3 className="text-[#576b95] font-bold text-sm mb-1">{user.name}</h3>
                <p className="text-gray-800 text-sm mb-2 whitespace-pre-wrap">{moment.content}</p>
                
                {moment.images.length > 0 && (
                  <div className={`grid gap-1 mb-2 ${moment.images.length === 1 ? 'grid-cols-1 max-w-[200px]' : 'grid-cols-3'}`}>
                    {moment.images.map((img, idx) => (
                      <img
                        key={idx}
                        src={img}
                        alt="Moment"
                        className="w-full h-24 object-cover"
                      />
                    ))}
                  </div>
                )}
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs text-gray-400">{getTimeAgo(moment.timestamp)}</span>
                  <div className="flex bg-[#f7f7f7] rounded px-2 py-1 space-x-3">
                       <div 
                           className={`flex items-center space-x-1 cursor-pointer hover:text-gray-600 ${isLiked ? 'text-red-500' : 'text-[#576b95]'}`}
                           onClick={() => handleLike(moment.id)}
                        >
                           <Heart size={14} fill={isLiked ? "currentColor" : "none"} />
                           <span className="text-xs">{moment.likedBy.length > 0 ? moment.likedBy.length : '赞'}</span>
                       </div>
                       <div 
                           className="flex items-center space-x-1 cursor-pointer hover:text-gray-600 text-[#576b95]"
                           onClick={() => setShowCommentInput(showCommentInput === moment.id ? null : moment.id)}
                        >
                           <MessageCircle size={14} />
                           <span className="text-xs">评论</span>
                       </div>
                  </div>
                </div>
                
                {/* Comment Input */}
                {showCommentInput === moment.id && (
                    <div className="mt-2 flex items-center space-x-2">
                        <input 
                            className="flex-1 border rounded px-2 py-1 text-sm outline-none focus:border-green-500"
                            placeholder="评论..."
                            value={commentText}
                            onChange={(e) => setCommentText(e.target.value)}
                        />
                        <button onClick={() => handleComment(moment.id)} className="text-[#07C160]">
                            <Send size={16} />
                        </button>
                    </div>
                )}

                {/* Like/Comment Section */}
                {(moment.likedBy.length > 0 || moment.comments.length > 0) && (
                    <div className="bg-[#f3f3f5] mt-2 p-2 rounded text-xs leading-5">
                         {moment.likedBy.length > 0 && (
                             <div className="text-[#576b95] mb-1">
                                 <Heart size={10} className="inline mr-1" />
                                 {moment.likedBy.map((uid, idx) => {
                                     const u = getUser(uid);
                                     return (
                                         <span key={uid}>{u.name}{idx < moment.likedBy.length - 1 ? ', ' : ''}</span>
                                     )
                                 })}
                             </div>
                         )}
                         {moment.comments.length > 0 && (
                            <div className={`pt-1 ${moment.likedBy.length > 0 ? 'border-t border-gray-200' : ''}`}>
                                {moment.comments.map(comment => (
                                    <p key={comment.id}>
                                        <span className="text-[#576b95] font-medium">{comment.userName}:</span> {comment.content}
                                    </p>
                                ))}
                            </div>
                         )}
                    </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Publish Modal */}
      {showPublish && (
          <div className="absolute inset-0 bg-white z-50 flex flex-col">
              <div className="h-[50px] flex items-center justify-between px-4 border-b">
                  <button onClick={() => setShowPublish(false)} className="text-gray-600">取消</button>
                  <button 
                    onClick={handlePublish} 
                    className={`bg-[#07C160] text-white px-4 py-1 rounded text-sm ${(!newContent && !newImage) ? 'opacity-50' : ''}`}
                  >
                      发表
                  </button>
              </div>
              <div className="p-4">
                  <textarea 
                      className="w-full h-32 outline-none resize-none text-base"
                      placeholder="这一刻的想法..."
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                  />
                  <div className="mt-4">
                      {newImage ? (
                          <div className="relative w-24 h-24">
                              <img src={newImage} className="w-full h-full object-cover rounded" />
                              <button 
                                  onClick={() => setNewImage(null)}
                                  className="absolute -top-2 -right-2 bg-gray-500 text-white rounded-full p-0.5"
                               >
                                  <X size={12} />
                              </button>
                          </div>
                      ) : (
                          <div 
                              className="w-24 h-24 bg-gray-100 flex items-center justify-center cursor-pointer rounded"
                              onClick={() => fileInputRef.current?.click()}
                          >
                              <ImageIcon className="text-gray-400" />
                          </div>
                      )}
                      <input type="file" ref={fileInputRef} accept="image/*" className="hidden" onChange={handleImageUpload} />
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default Moments;