export interface User {
  id: string;
  name: string;
  avatar: string;
  isBot?: boolean;
  walletBalance?: number;
  password?: string;
  wxid?: string; // WeChat ID
  isBanned?: boolean; // If true, user cannot send messages or post moments
  isDeveloper?: boolean; // Special Developer/Admin account
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: number;
  type: 'text' | 'image' | 'audio' | 'redPacket' | 'transfer';
  mediaUrl?: string;
  redPacket?: {
    amount: number;
    status: 'unclaimed' | 'claimed';
    claimedBy?: string;
  };
  transfer?: {
    amount: number;
    status: 'pending' | 'accepted';
    description?: string;
    recipientId?: string; // ID of the specific receiver
  };
}

export interface ChatSession {
  id: string;
  participantId?: string;
  participantIds?: string[];
  isGroup?: boolean;
  groupName?: string;
  lastMessage: string;
  lastMessageTime: number;
  unreadCount: number;
  messages: Message[];
}

export interface MomentComment {
  id: string;
  userId: string;
  userName: string; // Cache name for display
  content: string;
}

export interface Moment {
  id: string;
  userId: string;
  content: string;
  images: string[];
  likedBy: string[]; // List of User IDs
  comments: MomentComment[];
  timestamp: number;
}

export type Tab = 'chat' | 'contacts' | 'discover' | 'me';